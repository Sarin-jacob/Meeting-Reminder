import popup
popup.new_data()